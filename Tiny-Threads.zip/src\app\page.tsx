import { HomeSlider } from '@/components/home-slider';
import { PageWrapper } from '@/components/page-wrapper';
import { ProductsSection } from '@/components/products-section';
import { getApprovedProducts } from '@/lib/firestore-helper';

export default async function Home() {
  const products = await getApprovedProducts();

  return (
    <PageWrapper>
      <HomeSlider />
      <ProductsSection initialProducts={products} />
    </PageWrapper>
  );
}
