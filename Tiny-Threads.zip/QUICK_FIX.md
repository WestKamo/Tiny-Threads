# 🔥 Quick Fix for Firebase Permissions Error

## The Problem
You're seeing: **"FirebaseError: Missing or insufficient permissions"**

This is because Firestore security rules need to be deployed.

## ⚡ Quick Solution (5 minutes)

### Step 1: Go to Firebase Console
1. Open: https://console.firebase.google.com
2. Select project: **studio-6093932063-c4457**

### Step 2: Deploy Security Rules
1. Click **"Firestore Database"** in left sidebar
2. Click **"Rules"** tab at the top
3. Copy ALL the text from `firestore.rules` file in your project
4. Paste it into the rules editor (replace everything)
5. Click **"Publish"** button

### Step 3: Refresh Your App
- Go back to http://localhost:9002
- Refresh the page
- Error should be gone! ✅

## 📦 If No Products Show Up

The database is probably empty. Two options:

### Option A: Add via Sell Page
1. Go to `/sell` page in your app
2. Fill out the product form
3. Submit it
4. Go back to Firebase Console > Firestore Database > Data tab
5. Find your product and change `status` from "pending" to "approved"
6. Refresh homepage - product appears!

### Option B: Add Manually in Firebase
1. In Firebase Console > Firestore Database > Data tab
2. Click "Start collection"
3. Collection ID: `products`
4. Add a document with these fields:
   ```
   name: "Test Baby Onesie"
   category: "Onesies"
   ageGroup: "0-3 months"
   gender: "Boy"
   price: 149.99
   imageUrl: "https://via.placeholder.com/400"
   seller: "Test Seller"
   sellerId: "test123"
   status: "approved"
   description: "Cute baby clothes"
   material: "Cotton"
   color: "Blue"
   style: "Casual"
   ```

## ✅ That's It!

After deploying rules and adding a product, your app will work perfectly with all the new features:
- ✅ Product filters
- ✅ Favorites (stored locally)
- ✅ Shopping cart
- ✅ Search functionality

---

**Still stuck?** Check `FIREBASE_SETUP.md` for detailed instructions.
