# 🔧 Fix CORS Issue - Firebase Storage

## What's Happening

Your uploads are being blocked by CORS (Cross-Origin Resource Sharing) policy. This means Firebase Storage needs to be configured to allow requests from localhost.

---

## ✅ SOLUTION 1: Try New Storage URL (EASIEST)

I've updated your `firebase.ts` to use the new Firebase Storage URL.

### **Test it now:**

1. **Restart your dev server:**
   ```bash
   npm run dev
   ```

2. **Hard refresh browser** (Ctrl+Shift+R)

3. **Go to:** http://localhost:9002/sell

4. **Try uploading a product again**

5. **Watch console** (F12) - it should now work!

---

## 🔧 SOLUTION 2: Configure CORS (if Solution 1 doesn't work)

If the upload still fails with CORS error, you need to configure CORS on the Storage bucket using Google Cloud CLI.

### **Step 1: Install Google Cloud CLI**

**Download:** https://cloud.google.com/sdk/docs/install

- Windows: Download and run the installer
- Follow the installation wizard
- Restart your terminal after installation

### **Step 2: Login to Google Cloud**

Open a new terminal/PowerShell and run:
```bash
gcloud auth login
```

This will open a browser for you to log in with your Google account (the one you use for Firebase).

### **Step 3: Set Your Project**

```bash
gcloud config set project studio-6093932063-c4457
```

### **Step 4: Apply CORS Configuration**

In your project folder, I've created a `cors.json` file. Apply it:

```bash
gcloud storage buckets update gs://studio-6093932063-c4457.firebasestorage.app --cors-file=cors.json
```

**OR** if using the old bucket URL:

```bash
gcloud storage buckets update gs://studio-6093932063-c4457.appspot.com --cors-file=cors.json
```

### **Step 5: Verify CORS Was Applied**

```bash
gcloud storage buckets describe gs://studio-6093932063-c4457.firebasestorage.app --format="default(cors)"
```

You should see the CORS configuration displayed.

### **Step 6: Test Again**

1. Restart dev server: `npm run dev`
2. Hard refresh browser (Ctrl+Shift+R)
3. Try uploading at http://localhost:9002/sell

---

## 🆘 SOLUTION 3: Use Firebase Console (Alternative)

Unfortunately, Firebase Console doesn't have a UI for CORS configuration. You MUST use gcloud CLI (Solution 2) if Solution 1 doesn't work.

---

## ⚡ Quick Check: Which Storage Bucket URL?

Your Firebase project might be using one of two URLs:
- **New:** `studio-6093932063-c4457.firebasestorage.app`
- **Old:** `studio-6093932063-c4457.appspot.com`

### To check which one you have:

1. Go to Firebase Console: https://console.firebase.google.com/project/studio-6093932063-c4457/settings/general
2. Look for **"Storage bucket"** under "Your apps"
3. Note which URL format it shows

If it shows `.firebasestorage.app` → Solution 1 should work
If it shows `.appspot.com` → Revert firebase.ts and use Solution 2

---

## 📋 What I Changed

**File: `src/lib/firebase.ts`**
- Changed `storageBucket` from `.appspot.com` to `.firebasestorage.app`

**File: `cors.json`** (created)
- CORS configuration allowing all origins for development

---

## 🎯 Try This Order:

1. ✅ **Try Solution 1 first** (restart server + test)
2. ❌ **If still CORS error** → Use Solution 2 (gcloud CLI)
3. ✅ **Success!** → Your app should work

---

## 💡 Why This Happens

Firebase Storage uses CORS to protect your data. By default, it blocks requests from web browsers unless you explicitly configure which origins (domains) are allowed. Localhost needs to be explicitly allowed for development.

---

## ✅ Expected Success Output

When it works, console should show:
```
Starting image upload...
Uploading to: images/USER_ID/TIMESTAMP_filename.jpg
📤 Upload: 25% (34.4KB / 137.4KB)
📤 Upload: 50% (68.7KB / 137.4KB)
📤 Upload: 75% (103.1KB / 137.4KB)
📤 Upload: 100% (137.4KB / 137.4KB)
✅ Upload complete! URL: https://firebasestorage.googleapis.com/...
```

No CORS errors!

---

**Start with Solution 1 (restart server). If that doesn't work, let me know and we'll do Solution 2!**
