'use server';

import { generateProductDescription, type GenerateProductDescriptionInput } from '@/ai/flows/ai-suggested-product-descriptions';
import { db } from '@/lib/firebase';
import type { Product } from '@/lib/types';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import { revalidatePath } from 'next/cache';

export async function getAIDescription(data: GenerateProductDescriptionInput) {
  try {
    const result = await generateProductDescription(data);
    return { success: true, description: result.description };
  } catch (error) {
    console.error('AI description generation failed:', error);
    return { success: false, error: 'An error occurred while generating the description.' };
  }
}

export async function addProduct(productData: Omit<Product, 'id' | 'status' | 'createdAt'>) {
    try {
        console.log('Adding product to Firestore:', productData);
        const docRef = await addDoc(collection(db, 'products'), {
            ...productData,
            status: 'approved', // Auto-approve for development. Change to 'pending' in production
            createdAt: serverTimestamp(),
        });
        console.log('Product added successfully with ID:', docRef.id);
        revalidatePath('/');
        revalidatePath('/admin/approve');
        revalidatePath('/profile');
        return { success: true, productId: docRef.id };
    } catch (error: any) {
        console.error('Error adding product to Firestore:', error);
        console.error('Error code:', error?.code);
        console.error('Error message:', error?.message);
        return { 
            success: false, 
            error: error?.message || 'Failed to list product. Check Firestore rules and authentication.' 
        };
    }
}
