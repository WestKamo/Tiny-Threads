'use client';

import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
  FormDescription,
} from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent } from '@/components/ui/card';
import { ImagePlus, Loader2, Wand2, Upload } from 'lucide-react';
import { ageGroups, genders, materials, productCategories, styles } from '@/lib/data';
import { useState, useTransition, useRef } from 'react';
import { getAIDescription, addProduct } from '@/app/sell/actions';
import type { GenerateProductDescriptionInput } from '@/ai/flows/ai-suggested-product-descriptions';
import type { Product } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/hooks/use-auth';
import { useRouter } from 'next/navigation';
import { storage, db } from '@/lib/firebase';
import { ref, uploadBytesResumable, getDownloadURL } from 'firebase/storage';
import { addDoc, collection, serverTimestamp } from 'firebase/firestore';
import Image from 'next/image';

const formSchema = z.object({
  name: z.string().min(3, 'Product name must be at least 3 characters.'),
  category: z.string({ required_error: 'Please select a category.' }),
  ageGroup: z.string({ required_error: 'Please select an age group.' }),
  gender: z.string({ required_error: 'Please select a gender.' }),
  material: z.string({ required_error: 'Please select a material.' }),
  color: z.string().min(1, 'Please enter a color.'),
  style: z.string({ required_error: 'Please select a style.' }),
  price: z.coerce.number().min(0, 'Price must be a positive number.'),
  description: z.string().min(10, 'Description must be at least 10 characters.'),
  additionalFeatures: z.string().optional(),
  imageUrl: z.string().optional(),
  imageFile: z.instanceof(File).optional(),
}).refine(data => data.imageFile || data.imageUrl, {
    message: "Product image is required.",
    path: ["imageFile"],
});


export function AddProductForm() {
  const [isGenerating, startTransition] = useTransition();
  const [isSubmitting, startSubmitTransition] = useTransition();
  const { toast } = useToast();
  const { user } = useAuth();
  const router = useRouter();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: '',
      color: '',
      price: 0.0,
      description: '',
      additionalFeatures: '',
    },
  });

  const handleGenerateDescription = () => {
    const values = form.getValues();
    const { name, category, ageGroup, gender, material, color, style } = values;

    if (!name || !category || !ageGroup || !gender || !material || !color || !style) {
      toast({
        title: 'Missing Information',
        description: 'Please fill in all product details before generating a description.',
        variant: 'destructive',
      });
      return;
    }
    
    startTransition(async () => {
      const result = await getAIDescription(values as GenerateProductDescriptionInput);
      if (result.success && result.description) {
        form.setValue('description', result.description);
        toast({
          title: 'Description Generated!',
          description: 'The AI has created a description for your product.',
        });
      } else {
        toast({
          title: 'Error',
          description: result.error || 'Could not generate description.',
          variant: 'destructive',
        });
      }
    });
  };

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      form.setValue('imageFile', file);
      const reader = new FileReader();
      reader.onloadend = () => {
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if (!user) {
        return;
    }
    if (!values.imageFile) {
        toast({ title: "Image Required", description: "Please upload an image for the product.", variant: "destructive"});
        return;
    }
    startSubmitTransition(async () => {
      let uploadedUrl = '';
      try {
        console.log('Starting image upload...');
        const file = values.imageFile as File;
        if (file.size > 5 * 1024 * 1024) {
          toast({ title: 'Image Too Large', description: 'Please upload an image smaller than 5MB.', variant: 'destructive' });
          return;
        }
        const safeName = file.name.replace(/[^a-zA-Z0-9_.-]/g, '_');
        const imageRef = ref(storage, `images/${user.uid}/${Date.now()}_${safeName}`);
        console.log('Uploading to:', imageRef.fullPath, 'size:', file.size, 'type:', file.type);
        const uploadTask = uploadBytesResumable(imageRef, file, { contentType: file.type || 'image/jpeg' });

        uploadedUrl = await new Promise<string>((resolve, reject) => {
          const timeout = setTimeout(() => {
            console.error('⏰ Upload timed out after 60 seconds');
            console.error('📋 Checklist:');
            console.error('  1. Firebase Storage rules published?');
            console.error('  2. Storage bucket enabled in Firebase Console?');
            console.error('  3. User authenticated?', user ? '✅' : '❌');
            console.error('  4. Network/firewall blocking Firebase?');
            try { uploadTask.cancel(); } catch {}
            reject(new Error('Upload timeout (60s). Check: 1) Storage rules published in Console, 2) Storage enabled, 3) Network/ad-blockers'));
          }, 60000); // Increased to 60s

          uploadTask.on(
            'state_changed',
            (snapshot) => {
              const progress = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 100);
              const transferred = (snapshot.bytesTransferred / 1024).toFixed(1);
              const total = (snapshot.totalBytes / 1024).toFixed(1);
              console.log(`📤 Upload: ${progress}% (${transferred}KB / ${total}KB)`);
            },
            (err) => {
              clearTimeout(timeout);
              console.error('❌ Upload error:', err.code, err.message);
              reject(err);
            },
            async () => {
              clearTimeout(timeout);
              try {
                const url = await getDownloadURL(uploadTask.snapshot.ref);
                console.log('✅ Upload complete! URL:', url);
                resolve(url);
              } catch (err) {
                reject(err);
              }
            }
          );
        });

        console.log('Image URL:', uploadedUrl);
      } catch (error: any) {
        console.error('Image upload error:', error);
        console.error('Error code:', error?.code);
        console.error('Error message:', error?.message);
        toast({ title: 'Image Upload Failed', description: (error?.message || 'Could not upload the product image.') + ' If this persists, publish Storage rules, disable ad blockers, and try a smaller image (<2MB).', variant: 'destructive' });
        return;
      }

      // Write product to Firestore (client-side, not server action)
      try {
        const { imageFile, ...productValues } = values;
        const productData = {
          ...productValues,
          imageUrl: uploadedUrl,
          seller: user.displayName || user.email || 'Anonymous',
          sellerId: user.uid,
          status: 'approved', // Auto-approve for development
          createdAt: serverTimestamp(),
        };

        console.log('Writing product to Firestore:', productData);
        const docRef = await addDoc(collection(db, 'products'), productData);
        console.log('✅ Product added successfully with ID:', docRef.id);
        
        toast({ title: 'Product Listed Successfully!', description: 'Your item is now live and visible on the homepage!' });
        form.reset();
        setImagePreview(null);
        router.push('/');
      } catch (error: any) {
        console.error('❌ Firestore write error:', error);
        console.error('Error code:', error?.code);
        console.error('Error message:', error?.message);
        toast({ title: 'Failed to Save Product', description: error?.message || 'Could not save product to database. Check Firestore rules.', variant: 'destructive' });
      }
    });
  }

  return (
    <Card>
      <CardContent className="p-6">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
            <FormField
              control={form.control}
              name="imageFile"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product Image</FormLabel>
                  <FormControl>
                    <div 
                      className="w-full h-48 border-2 border-dashed rounded-lg flex flex-col items-center justify-center text-muted-foreground hover:bg-accent/50 transition-colors cursor-pointer relative"
                      onClick={() => fileInputRef.current?.click()}
                    >
                      {imagePreview ? (
                        <Image src={imagePreview} alt="Product preview" fill className="object-cover rounded-md" />
                      ) : (
                        <>
                          <ImagePlus className="h-10 w-10 mb-2" />
                          <span className="font-medium">Click to Upload Image</span>
                        </>
                      )}
                      <Input 
                        type="file" 
                        ref={fileInputRef} 
                        className="hidden" 
                        accept="image/*"
                        onChange={handleImageChange}
                      />
                    </div>
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Product Name</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 'Cozy Blue Onesie'" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Category</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select a category" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {productCategories.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="ageGroup"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Age Group</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select an age group" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {ageGroups.map((ag) => <SelectItem key={ag} value={ag}>{ag}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <FormField
                control={form.control}
                name="gender"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Gender</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select a gender" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {genders.map((g) => <SelectItem key={g} value={g}>{g}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="price"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Price</FormLabel>
                    <FormControl>
                      <Input type="number" placeholder="249.99" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <FormField
                control={form.control}
                name="material"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Material</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select material" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {materials.map((m) => <SelectItem key={m} value={m}>{m}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="color"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Color</FormLabel>
                    <FormControl>
                      <Input placeholder="e.g., 'Pastel Blue'" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="style"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Style</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger><SelectValue placeholder="Select style" /></SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {styles.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="additionalFeatures"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Additional Features (Optional)</FormLabel>
                  <FormControl>
                    <Input placeholder="e.g., 'Snap buttons, ruffles'" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <div className="flex justify-between items-center">
                    <FormLabel>Product Description</FormLabel>
                    <Button type="button" variant="outline" size="sm" onClick={handleGenerateDescription} disabled={isGenerating}>
                      {isGenerating ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Wand2 className="mr-2 h-4 w-4" />
                      )}
                      Generate with AI
                    </Button>
                  </div>
                  <FormControl>
                    <Textarea
                      placeholder="Describe the item, its condition, and any special features."
                      className="min-h-[120px]"
                      {...field}
                    />
                  </FormControl>
                  <FormDescription>
                    A well-written description helps your item sell faster.
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <Button type="submit" size="lg" className="w-full" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              List Item for Sale
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
