# Firebase Setup Guide - Fix Permissions Error

## 🔥 Issue: "Missing or insufficient permissions"

This error occurs because Firestore security rules haven't been deployed yet.

## ✅ Solution: Deploy Firestore Rules

### Option 1: Using Firebase Console (Recommended - Easiest)

1. **Go to Firebase Console**
   - Visit: https://console.firebase.google.com
   - Select your project

2. **Navigate to Firestore Database**
   - Click "Firestore Database" in the left sidebar
   - Click on the "Rules" tab at the top

3. **Update the Rules**
   - Copy the contents from `firestore.rules` file in your project
   - Paste it into the rules editor
   - Click "Publish" button

4. **Refresh Your App**
   - The error should be gone!

### Option 2: Using Firebase CLI

If you have Firebase CLI installed:

```bash
# Install Firebase CLI (if not installed)
npm install -g firebase-tools

# Login to Firebase
firebase login

# Deploy only the Firestore rules
firebase deploy --only firestore:rules
```

## 📋 Current Firestore Rules

The `firestore.rules` file has been created with the following permissions:

```
- ✅ Anyone can READ approved products (no auth required)
- ✅ Authenticated users can CREATE products (status: pending)
- ✅ Sellers can UPDATE their own products
- ✅ Only admins can DELETE products
- ✅ Users can read/write their own user data
```

## 🗄️ Database Structure

Your Firestore should have this structure:

```
/products/{productId}
  - name: string
  - category: string
  - ageGroup: string
  - gender: string
  - price: number
  - imageUrl: string
  - seller: string
  - sellerId: string
  - status: "pending" | "approved" | "rejected"
  - description: string
  - material: string
  - color: string
  - style: string
  - additionalFeatures: string (optional)
  - createdAt: timestamp

/users/{userId}
  - displayName: string
  - email: string
  - role: "buyer" | "seller" | "admin"
  - createdAt: timestamp
```

## 🎯 Quick Test

After deploying the rules:

1. **Check if the error is gone** - Refresh your app
2. **Add a test product** - Go to the Sell page and create a product
3. **Approve it in Firebase Console** - Change status from "pending" to "approved"
4. **See it on homepage** - The product should appear

## 🚨 If You Still See Errors

### No Products Showing?
- The database might be empty
- Add some test products through the Sell page
- Or manually add products in Firebase Console

### Still Getting Permission Errors?
1. Check if rules are published in Firebase Console
2. Make sure you're using the correct Firebase project
3. Verify `.firebaserc` has the correct project ID

### Authentication Issues?
- Make sure Firebase Authentication is enabled
- Enable Email/Password sign-in method in Firebase Console
- Go to: Authentication > Sign-in method > Enable Email/Password

## 📝 Sample Product Data

You can manually add this test product in Firebase Console:

```json
{
  "name": "Cute Blue Onesie",
  "category": "Onesies",
  "ageGroup": "0-3 months",
  "gender": "Boy",
  "price": 149.99,
  "imageUrl": "https://via.placeholder.com/400x400?text=Baby+Onesie",
  "seller": "Test Seller",
  "sellerId": "test123",
  "status": "approved",
  "description": "Adorable soft cotton onesie perfect for newborns",
  "material": "Cotton",
  "color": "Blue",
  "style": "Casual",
  "createdAt": "2025-09-30T09:00:00.000Z"
}
```

## ✅ After Setup

Once rules are deployed and you have some products:
- Homepage will show all approved products
- Filters will work on those products
- Favorites will work (stored locally)
- Shopping cart will work

---

**Need Help?** Check the Firebase Console logs for detailed error messages.
