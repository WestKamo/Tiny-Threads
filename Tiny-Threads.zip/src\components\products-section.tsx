'use client';

import { useState, useMemo } from 'react';
import { ProductCard } from './product-card';
import { ProductFilters } from './product-filters';
import { CompleteTheOutfit } from './complete-the-outfit';
import type { Product } from '@/lib/types';

interface ProductsSectionProps {
  initialProducts: Product[];
}

export interface FilterState {
  search: string;
  category: string;
  ageGroup: string;
  gender: string;
  priceRange: [number, number];
}

export function ProductsSection({ initialProducts }: ProductsSectionProps) {
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    category: 'all',
    ageGroup: 'all',
    gender: 'all',
    priceRange: [0, 1000],
  });

  const filteredProducts = useMemo(() => {
    return initialProducts.filter((product) => {
      // Search filter
      if (filters.search && !product.name.toLowerCase().includes(filters.search.toLowerCase())) {
        return false;
      }

      // Category filter
      if (filters.category !== 'all' && product.category.toLowerCase() !== filters.category) {
        return false;
      }

      // Age group filter
      if (filters.ageGroup !== 'all' && product.ageGroup.toLowerCase() !== filters.ageGroup) {
        return false;
      }

      // Gender filter
      if (filters.gender !== 'all' && product.gender.toLowerCase() !== filters.gender) {
        return false;
      }

      // Price range filter
      if (product.price < filters.priceRange[0] || product.price > filters.priceRange[1]) {
        return false;
      }

      return true;
    });
  }, [initialProducts, filters]);

  return (
    <section className="container mx-auto px-4 py-8 md:py-12">
      <div className="grid grid-cols-1 lg:grid-cols-4 lg:gap-12">
        <aside className="lg:col-span-1 mb-8 lg:mb-0">
          <div className="space-y-8">
            <ProductFilters filters={filters} onFiltersChange={setFilters} />
            <CompleteTheOutfit />
          </div>
        </aside>
        <div className="lg:col-span-3">
          <div className="flex justify-between items-center mb-8">
            <h2 className="text-3xl font-bold tracking-tight">Our Products</h2>
            <p className="text-muted-foreground">
              {filteredProducts.length} {filteredProducts.length === 1 ? 'item' : 'items'}
            </p>
          </div>
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-8">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="text-center py-16 border-2 border-dashed rounded-lg">
              <h3 className="text-2xl font-semibold mb-2">No products found</h3>
              <p className="text-muted-foreground">
                Try adjusting your filters to see more results.
              </p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
