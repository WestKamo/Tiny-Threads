# 🧪 Quick Test Checklist

## Before Testing Products

### 1. ✅ Firestore Rules Deployed?
- [ ] Go to https://console.firebase.google.com
- [ ] Select project: `studio-6093932063-c4457`
- [ ] Firestore Database → Rules tab
- [ ] Copy from `firestore.rules` file
- [ ] Click "Publish"
- [ ] See "Rules published successfully" message

### 2. ✅ Logged In?
- [ ] Go to your app: http://localhost:9002
- [ ] Top-right corner shows your email/name?
- [ ] If not: Go to `/signup` or `/login`

### 3. ✅ Browser Console Open?
- [ ] Press F12 (or Right-click → Inspect)
- [ ] Click "Console" tab
- [ ] Clear any old messages

## Test: List a Product

### Step 1: Go to Sell Page
- [ ] Navigate to `/sell` in your app
- [ ] See the product form?

### Step 2: Fill Minimum Required Fields
```
Product Name: Test Baby Onesie
Category: Onesies
Age Group: 0-3 months
Gender: Boy
Material: Cotton
Color: Blue
Style: Casual
Price: 99.99
Description: This is a test product
Image: Upload any image
```

### Step 3: Submit
- [ ] Click "List Item for Sale" button
- [ ] Watch the browser console

### Step 4: Check Results

**Expected Success:**
- [ ] See toast: "Product Listed Successfully!"
- [ ] Redirected to homepage
- [ ] Product appears in the grid
- [ ] Console shows: "Product added successfully with ID: [some-id]"

**If Error:**
- [ ] Check console for error message
- [ ] Copy the exact error
- [ ] See TROUBLESHOOTING.md

### Step 5: Verify in Firebase
- [ ] Go to Firebase Console
- [ ] Firestore Database → Data tab
- [ ] See "products" collection?
- [ ] See your test product?
- [ ] Status is "approved"?

### Step 6: Test Features
- [ ] Product visible on homepage? ✅
- [ ] Can search for it? ✅
- [ ] Can filter by category? ✅
- [ ] Can add to favorites (heart icon)? ✅
- [ ] Can add to cart? ✅

## 🚨 If Test Fails

### Error: "Missing or insufficient permissions"
→ **Firestore rules not deployed!** Go back to Step 1

### Error: "Authentication Error"  
→ **Not logged in!** Go to `/login`

### Error: "Image Required"
→ **Upload an image!** Click the upload area

### No error but product doesn't appear
→ Check Firebase Console to see if product was created

### Product created but not visible
→ Check if status is "approved" in Firebase

## ✅ Success Criteria

All of these should work:
- ✅ Can create product without errors
- ✅ Product appears on homepage immediately
- ✅ Can see product in Firebase Console
- ✅ Status is "approved"
- ✅ Can interact with product (favorite, cart)

---

**After successful test**: Your app is working! You can now list real products.
