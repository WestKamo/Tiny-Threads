"use client";

import Image, { ImageProps } from "next/image";
import { useState } from "react";

// A robust Image wrapper that swaps to a fallback when the source 404s or errors.
// Usage: <SafeImage src={url} alt="..." fill className="..." />

const FALLBACK_DATA_URL =
  "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='600'><rect width='100%' height='100%' fill='%23A0D2EB'/><text x='50%' y='50%' dominant-baseline='middle' text-anchor='middle' fill='%23ffffff' font-family='Arial' font-size='42'>Tiny Threads</text></svg>";

export function SafeImage(props: ImageProps) {
  const { src, alt, ...rest } = props;
  const [imgSrc, setImgSrc] = useState(src);

  return (
    <Image
      {...rest}
      alt={alt}
      src={imgSrc}
      onError={() => {
        // Swap to a lightweight inline fallback to avoid blocking UI
        setImgSrc(FALLBACK_DATA_URL);
      }}
    />
  );
}
