# Firebase Storage Setup Guide

## ⚠️ CRITICAL: You MUST publish Storage rules before uploads will work!

### Step 1: Open Firebase Console
1. Go to: https://console.firebase.google.com/
2. Select your project: **studio-6093932063-c4457**

### Step 2: Navigate to Storage
1. Click **"Storage"** in the left sidebar
2. If you see "Get Started", click it to enable Storage
3. Choose your region (any region is fine for dev)

### Step 3: Publish Storage Rules
1. Click the **"Rules"** tab at the top
2. You should see a rules editor
3. **Copy the entire content from `storage.rules` file in your project root**
4. Paste it into the Firebase Console rules editor
5. Click **"Publish"** button (top right)
6. Wait for "Rules published successfully" message

### Step 4: Verify Storage is Enabled
1. Click the **"Files"** tab
2. You should see an empty file browser (not an error)
3. If you see "Storage not enabled", click the button to enable it

---

## 🧪 Testing the Upload

### After publishing rules:

1. **Restart your dev server:**
   ```bash
   npm run dev
   ```

2. **Hard refresh browser** (Ctrl+Shift+R or Cmd+Shift+R)

3. **Open browser console** (F12 → Console tab)

4. **Try uploading a product:**
   - Go to http://localhost:3000/sell
   - Make sure you're logged in
   - Upload a small image (<1MB for testing)
   - Fill in all fields
   - Click "List Item for Sale"

5. **Watch the console logs:**
   - ✅ **Good signs:**
     ```
     Firebase Storage initialized: studio-6093932063-c4457.appspot.com
     Starting image upload...
     Uploading to: images/USER_ID/TIMESTAMP_filename.jpg
     📤 Upload: 25% (50.2KB / 200.8KB)
     📤 Upload: 50% (100.4KB / 200.8KB)
     📤 Upload: 75% (150.6KB / 200.8KB)
     📤 Upload: 100% (200.8KB / 200.8KB)
     ✅ Upload complete! URL: https://firebasestorage.googleapis.com/...
     ```
   
   - ❌ **Bad signs (rules not published):**
     ```
     ⏰ Upload timed out after 60 seconds
     📋 Checklist:
       1. Firebase Storage rules published?
       2. Storage bucket enabled in Firebase Console?
       3. User authenticated? ✅
       4. Network/firewall blocking Firebase?
     ```

---

## 🔧 Troubleshooting

### If upload still times out after publishing rules:

#### 1. Check Authentication
   - Console should show: `User authenticated? ✅`
   - If it shows `❌`, log out and log back in

#### 2. Disable Browser Extensions
   - Ad blockers (uBlock Origin, AdBlock, etc.)
   - Privacy extensions
   - Try in Incognito/Private mode

#### 3. Check Network
   - Corporate firewall blocking Firebase?
   - VPN interfering?
   - Try on different network (mobile hotspot)

#### 4. Verify Rules Took Effect
   - Go back to Firebase Console → Storage → Rules
   - Make sure you see your rules, not the default ones
   - The published date should be recent

#### 5. Clear Browser Cache
   - Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
   - Or clear all browser cache for localhost

#### 6. Try Smaller Image
   - Use a tiny test image (<100KB)
   - Simple JPEG or PNG

---

## 📝 Current Storage Rules

Your `storage.rules` file allows:
- **Read**: Anyone can read/download images
- **Write**: Only authenticated users can upload to `/images/`

```
rules_version = '2';

service firebase.storage {
  match /b/{bucket}/o {
    // Allow anyone to read images
    match /{allPaths=**} {
      allow read: if true;
    }
    
    // Allow authenticated users to upload images to their own folder
    match /images/{userId}/{allPaths=**} {
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    
    // For development: Allow any authenticated user to upload anywhere
    match /images/{allPaths=**} {
      allow write: if request.auth != null;
    }
  }
}
```

---

## ✅ Success Checklist

- [ ] Firebase Console opened for project: studio-6093932063-c4457
- [ ] Storage enabled (not showing "Get Started")
- [ ] Storage rules published (copied from storage.rules file)
- [ ] Dev server restarted
- [ ] Browser hard refreshed
- [ ] Logged in as a user
- [ ] Console shows "Firebase Storage initialized"
- [ ] Upload shows progress logs (25%, 50%, 75%, 100%)
- [ ] Upload completes with URL
- [ ] Product appears on homepage

---

## 🆘 Still Not Working?

If you've done ALL the above and it still doesn't work:

1. **Check Firebase Console → Storage → Usage**
   - Does it show any activity?
   - Any error messages?

2. **Check Browser Network Tab** (F12 → Network)
   - Filter by "firebasestorage"
   - Do you see any requests?
   - What's their status code?
   - Red = blocked/failed
   - Green = success

3. **Test with Firebase SDK directly in console:**
   ```javascript
   import { storage } from './src/lib/firebase';
   import { ref, uploadString } from 'firebase/storage';
   const testRef = ref(storage, 'test.txt');
   uploadString(testRef, 'Hello World').then(() => console.log('Success!')).catch(err => console.error(err));
   ```

4. **Last resort: Check Firebase project settings**
   - Firebase Console → Project Settings → General
   - Make sure storage bucket is listed
   - Make sure it matches: studio-6093932063-c4457.appspot.com
