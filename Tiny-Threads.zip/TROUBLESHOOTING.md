# 🔧 Troubleshooting: Products Not Appearing

## Step-by-Step Checklist

### ✅ Step 1: Check if Firestore Rules Are Deployed

**This is the #1 reason products don't work!**

1. Go to: https://console.firebase.google.com
2. Select project: `studio-6093932063-c4457`
3. Click **"Firestore Database"** in left sidebar
4. Click **"Rules"** tab at the top
5. **Verify the rules match your `firestore.rules` file**
6. If not, copy from `firestore.rules` and click **"Publish"**

### ✅ Step 2: Check if You're Logged In

Products require authentication to create:

1. Look at the top-right of your app
2. Do you see your email/name? ✅ Good!
3. If not, go to `/login` or `/signup` first

### ✅ Step 3: Try Listing a Product

1. Go to `/sell` page
2. Fill out ALL required fields:
   - Product name
   - Category
   - Age group
   - Gender
   - Material
   - Color
   - Style
   - Price
   - Description
   - **Upload an image** (required!)
3. Click "List Item for Sale"

### ✅ Step 4: Check for Errors

**Open Browser Console** (F12 or Right-click → Inspect → Console tab)

Look for errors:

#### Error: "Missing or insufficient permissions"
- **Fix**: Deploy Firestore rules (Step 1 above)

#### Error: "Authentication Error"
- **Fix**: Log in first at `/login`

#### Error: "Image Required"
- **Fix**: Upload an image before submitting

#### Error: "Failed to list product"
- Check console for detailed error message
- Verify Firebase config is correct

### ✅ Step 5: Check if Product Was Created

1. Go to Firebase Console
2. Click "Firestore Database" → "Data" tab
3. Look for "products" collection
4. Do you see your product? 
   - **YES**: Check if `status` is "approved"
   - **NO**: There was an error creating it (check console)

### ✅ Step 6: Verify Product Appears on Homepage

After successful submission:
- You should be redirected to homepage
- Your product should be visible
- Try using filters to find it

## 🐛 Common Issues & Solutions

### Issue: "Product submitted but not showing"

**Solution 1**: Check product status
- Go to Firebase Console → Firestore → products
- Find your product
- Verify `status` field is "approved" (not "pending")

**Solution 2**: Clear cache and refresh
- Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)

**Solution 3**: Check filters
- Make sure filters aren't hiding your product
- Reset all filters to "All"

### Issue: "Image upload fails"

**Solution**: Check Firebase Storage rules
1. Go to Firebase Console → Storage
2. Click "Rules" tab
3. Use these rules:
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /images/{userId}/{allPaths=**} {
      allow read: if true;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
  }
}
```

### Issue: "Nothing happens when I submit"

**Check**:
1. Are you logged in?
2. Did you fill ALL required fields?
3. Did you upload an image?
4. Check browser console for errors

## 🔍 Debug Mode

I've added detailed logging. Check your browser console for:
- "Adding product to Firestore:" - Shows product data
- "Product added successfully with ID:" - Shows success
- "Error adding product:" - Shows what went wrong

## 📞 Still Not Working?

If you've tried everything above:

1. **Share the console error** - Copy the exact error message
2. **Check Firebase Console** - See if product was created
3. **Verify authentication** - Make sure you're logged in
4. **Check Firestore rules** - Make sure they're published

## ✅ Expected Flow

When everything works correctly:

1. Fill form → Click submit
2. See "Product Listed Successfully!" toast
3. Redirect to homepage
4. Product appears in the grid
5. Can filter/search for it
6. Can add to favorites/cart

---

**Quick Test**: Try listing a simple product with minimal info to test if the basic flow works.
